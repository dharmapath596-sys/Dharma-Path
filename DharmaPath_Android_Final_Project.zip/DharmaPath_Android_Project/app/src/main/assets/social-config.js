window.DHARMA_PATH_CONFIG={supabaseUrl:'https://YOUR-PROJECT.supabase.co',supabaseAnonKey:'YOUR-SUPABASE-ANON-KEY',ownerEmail:'YOUR-OWNER-EMAIL',timezone:'Asia/Dhaka'};
