ধর্ম পথ — Android Release Project

এই প্রজেক্টে Final 2026–2038 HTML অ্যাপটি Android WebView-এর ভিতরে প্যাক করা হয়েছে।
Target/Compile SDK: 36 (Android 16), Google Play-এর 2026 নতুন-app requirement অনুযায়ী।
Application ID: com.dharmapath.app

গুরুত্বপূর্ণ:
এটি বর্তমান Final UI/ধর্মীয় ডাটা Android package করার ভিত্তি। সত্যিকারের online social network করতে server/database/authentication/media storage প্রয়োজন। এই project-এ কোনো ব্যক্তিগত Firebase/Supabase credential বসানো হয়নি। তাই account/post/like/comment/follow সবার মধ্যে online sync করতে owner-এর backend project লাগবে।

Android Studio-তে:
1) Open → এই folder নির্বাচন করুন
2) Gradle sync হতে দিন
3) Build → Generate Signed App Bundle / APK
4) Play Store-এর জন্য Android App Bundle (.aab) বানাবেন

Google Play-এর জন্য signing key নিরাপদে সংরক্ষণ করবেন।
